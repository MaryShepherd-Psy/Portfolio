---
title: Contact
---

# Contact

- **Email:** mary.shepherd.mn@gmail.com  
- **LinkedIn:** https://www.linkedin.com/in/maryshepherd-leadership-agile/  

_Optional: calendar link, speaking requests, media kit._
