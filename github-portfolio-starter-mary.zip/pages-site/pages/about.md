---
title: About
---

# About

I operate at the intersection of **engineering integration, human systems, and delivery discipline**.

- NASA/DoD/FAA environments, milestone gates (SRR→FRR)
- Agile/Scaled Agile coaching (Scrum, Kanban, SAFe), Scrum of Scrums
- Integrated Master Scheduling (Primavera P6, MS Project, Milestones Pro)
- People Analytics & Organizational Development (psychological safety, training 400–500+ staff)
- Tooling: Jira, Confluence, Power BI, DOORS Next, Jama, CATIA/3DEXPERIENCE (familiar), SAP/Oracle

_Add a short personal narrative, values, and working style._
