---
title: Projects
---

# Projects

Each project gets a concise card here and (optionally) a detailed page in `/projects/<name>`.

## Agile Culture Reset — Axiom Space
- **Role:** Sr. PM / People Analytics / IMS Coordinator  
- **Scope:** Avionics, ECLSS, Structures, GNC, Payloads, QA, Ground Ops  
- **Outcomes:** Improved milestone readiness; standardized flow metrics and artifacts  
- **Read more:** [Case Study](../projects/sample-project/README.md)

## AI/ML Tolling Modernization — HCTRA
- **Role:** Program Lead (Change & Integration)  
- **Outcomes:** Risk‑managed rollout, cost savings, faster anomaly resolution  
- **Artifacts:** _Add links_
