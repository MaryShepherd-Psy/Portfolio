# Agile Culture Reset — Axiom Space (Case Study)

**Timeline:** _May 2022 – Mar 2025_  
**Role:** Sr. PM / People Analytics / IMS Coordinator  
**Systems/Teams:** Avionics, ECLSS, Structures, GNC, Payloads, Ground Ops, QA

## Context
_Paste a tight narrative of the problem, constraints, and stakes._

## Approach
- Cadence: Scrum/Scrum of Scrums; standardized rituals
- Flow metrics: throughput, velocity, CFD, WIP limits
- NASA gates: SRR→FRR artifact readiness & dry‑runs
- IMS alignment: Primavera P6/MS Project/Milestones Pro

## Outcomes
- _Quantified impact: delivery predictability, defects, rework, readiness rates, etc._

## Artifacts
- Links to: Jira dashboards, Confluence pages, slide decks, trainings (as allowed)
