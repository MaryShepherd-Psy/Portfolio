---
title: Home
---

# Mary Shepherd

**Program & Culture Transformation · Aerospace/Defense**  
Agile + IMS + I/O Psychology

I build predictable delivery in complex engineering environments and design cultures where teams perform at their best.

[Projects](./pages/projects.md) · [About](./pages/about.md) · [Contact](./pages/contact.md)

---

## Signature Work
- **Agile Culture Reset in Private Aerospace Mission Support (Axiom Space)**  
  Milestone readiness (SRR→FRR), cross‑functional reviews, standardized flow metrics and rituals.

- **AI/ML Tolling Modernization (HCTRA)**  
  Risk‑managed integration, cost savings, faster anomaly resolution.

> _Bring your best content from your Google Doc and paste it into the pages below._
