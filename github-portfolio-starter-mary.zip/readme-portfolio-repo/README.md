# Mary Shepherd — Portfolio

_Agile Program Leader · IMS Specialist · Industrial & Organizational Psychologist (Aerospace/Defense)_

> **Quick pitch:** I turn complex, multi‑discipline programs into predictable delivery using Agile, systems thinking, and human‑centered design. I thrive at the intersection of engineering, operations, and culture.

## Highlights
- NASA/DoD/FAA environments; milestone gates (SRR→FRR), cross‑functional integration
- Agile/Scaled Agile coaching (Scrum, Kanban, SAFe), Scrum of Scrums, flow metrics (CFD, throughput)
- IMS (Primavera P6, MS Project, Milestones Pro); risk‑adjusted schedules; dependency mapping
- People Analytics & OD; psychological safety; training 400–500+ engineers and staff
- Tooling: Jira, Confluence, Power BI, DOORS Next, Jama, CATIA/3DEXPERIENCE (familiar), SAP/Oracle

## Selected Projects
- **Agile Culture Reset in Private Aerospace Mission Support** — Axiom Space (Case Study)  
  _Role:_ Sr. PM / People Analytics / IMS Coordinator  
  _Impact:_ Improved milestone readiness and cross‑team flow; standardized rituals, metrics, and artifacts.

- **AI/ML Modernization for Tolling Operations** — Harris County Toll Road Authority  
  _Role:_ Program Lead (Change & Integration)  
  _Impact:_ Risk‑managed rollout, cost savings, faster anomaly resolution.

_Add more projects below using the template:_

### Project Template
**Name:** _Project Title_  
**Org/Client:** _Company/Team_  
**Timeline:** _MMM YYYY – MMM YYYY_  
**Role:** _Your role_  
**Scope:** _Systems/teams involved_  
**What changed:** _Problem → Solution_  
**Outcomes:** _Metrics, delivery, quality, culture_  
**Artifacts:** _Links to docs, demos, papers, slides_

## Publications & Talks
- _Title_ — where, when, link
- _Title_ — where, when, link

## Contact
- **Email:** mary.shepherd.mn@gmail.com
- **LinkedIn:** https://www.linkedin.com/in/maryshepherd-leadership-agile/

---
> _Tip:_ Keep this README concise and link out to your GitHub Pages site for visuals and deeper case studies.
