# How to Use This Starter

This kit gives you **both**:
1) A README-based portfolio repo (`readme-portfolio-repo/`)
2) A GitHub Pages site (`pages-site/`)

## A) README‑based portfolio
1. Create a new repo in GitHub (e.g., `portfolio`).
2. Upload the contents of `readme-portfolio-repo/` (or push via git).
3. Edit `README.md` to paste content from your Google Doc.

## B) GitHub Pages site
**Option 1 (user site):** Create a repo named `<your-username>.github.io`, upload `pages-site/` contents, commit to `main`.
**Option 2 (project site):** Create any repo name, upload `pages-site/`, then go to Settings → Pages and set source to `main`.

- Edit `index.md`, `pages/about.md`, `pages/projects.md`, and the project README templates under `projects/`.
- You can change the theme in `_config.yml` (e.g., `jekyll-theme-minimal`, `jekyll-theme-cayman`).

## Tips
- Keep images under `assets/images/` and link from markdown.
- Keep both the README and the Pages site in sync by copying the same content (or link one to the other).
- Update often; commit with meaningful messages.
